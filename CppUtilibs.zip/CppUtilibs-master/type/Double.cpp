#include "Double.h"


namespace szx
{

double Double::error = 0.00001;

}